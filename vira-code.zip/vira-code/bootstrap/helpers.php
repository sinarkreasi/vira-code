<?php
/**
 * Helper Functions for Vira Code
 *
 * @package ViraCode
 */

namespace ViraCode;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get the plugin instance.
 *
 * @return App
 */
function app() {
	return App::getInstance();
}

/**
 * Get the plugin path.
 *
 * @param string $path Optional path to append.
 * @return string
 */
function vira_code_path( $path = '' ) {
	return VIRA_CODE_PATH . ltrim( $path, '/' );
}

/**
 * Get the plugin URL.
 *
 * @param string $path Optional path to append.
 * @return string
 */
function vira_code_url( $path = '' ) {
	return VIRA_CODE_URL . ltrim( $path, '/' );
}

/**
 * Get the plugin version.
 *
 * @return string
 */
function vira_code_version() {
	return VIRA_CODE_VERSION;
}

/**
 * Check if safe mode is enabled.
 *
 * @return bool
 */
function vira_code_is_safe_mode() {
	// Check URL parameter first.
	if ( isset( $_GET['vira_safe_mode'] ) && '1' === $_GET['vira_safe_mode'] ) {
		return true;
	}

	// Check option.
	return (bool) get_option( 'vira_code_safe_mode', 0 );
}

/**
 * Enable safe mode.
 *
 * @return bool
 */
function vira_code_enable_safe_mode() {
	return update_option( 'vira_code_safe_mode', 1 );
}

/**
 * Disable safe mode.
 *
 * @return bool
 */
function vira_code_disable_safe_mode() {
	return update_option( 'vira_code_safe_mode', 0 );
}

/**
 * Get snippet types.
 *
 * @return array
 */
function vira_code_snippet_types() {
	return apply_filters(
		'vira_code/snippet_types',
		array(
			'php'  => __( 'PHP', 'vira-code' ),
			'js'   => __( 'JavaScript', 'vira-code' ),
			'css'  => __( 'CSS', 'vira-code' ),
			'html' => __( 'HTML', 'vira-code' ),
		)
	);
}

/**
 * Get snippet scopes.
 *
 * @return array
 */
function vira_code_snippet_scopes() {
	return apply_filters(
		'vira_code/snippet_scopes',
		array(
			'frontend'   => __( 'Frontend', 'vira-code' ),
			'admin'      => __( 'Admin', 'vira-code' ),
			'both'       => __( 'Both', 'vira-code' ),
			'everywhere' => __( 'Everywhere', 'vira-code' ),
		)
	);
}

/**
 * Get snippet statuses.
 *
 * @return array
 */
function vira_code_snippet_statuses() {
	return apply_filters(
		'vira_code/snippet_statuses',
		array(
			'active'   => __( 'Active', 'vira-code' ),
			'inactive' => __( 'Inactive', 'vira-code' ),
			'error'    => __( 'Error', 'vira-code' ),
		)
	);
}

/**
 * Sanitize snippet code based on type.
 *
 * @param string $code Code to sanitize.
 * @param string $type Snippet type.
 * @return string
 */
function vira_code_sanitize_code( $code, $type ) {
	// Apply filters for custom sanitization.
	$code = apply_filters( 'vira_code/sanitize_code', $code, $type );
	$code = apply_filters( "vira_code/sanitize_code/{$type}", $code );

	// Basic sanitization - remove dangerous functions for non-PHP.
	if ( 'php' !== $type ) {
		$code = wp_kses_post( $code );
	}

	return $code;
}

/**
 * Log snippet execution.
 *
 * @param int    $snippet_id Snippet ID.
 * @param string $status     Execution status (success, error).
 * @param string $message    Optional message.
 * @return void
 */
function vira_code_log_execution( $snippet_id, $status, $message = '' ) {
	$log = array(
		'snippet_id' => $snippet_id,
		'status'     => $status,
		'message'    => $message,
		'timestamp'  => current_time( 'mysql' ),
	);

	// Store in transient for 7 days.
	$logs = get_transient( 'vira_code_execution_logs' );
	if ( ! is_array( $logs ) ) {
		$logs = array();
	}

	$logs[] = $log;

	// Keep only last 100 logs.
	if ( count( $logs ) > 100 ) {
		$logs = array_slice( $logs, -100 );
	}

	set_transient( 'vira_code_execution_logs', $logs, 7 * DAY_IN_SECONDS );

	// Fire action for custom logging.
	do_action( 'vira_code/log_execution', $log );
}

/**
 * Get execution logs.
 *
 * @param int $limit Optional limit.
 * @return array
 */
function vira_code_get_logs( $limit = 100 ) {
	$logs = get_transient( 'vira_code_execution_logs' );
	if ( ! is_array( $logs ) ) {
		return array();
	}

	if ( $limit > 0 ) {
		return array_slice( $logs, -$limit );
	}

	return $logs;
}

/**
	* Get the configured log limit.
	*
	* @return int
	*/
function vira_code_get_log_limit() {
	return (int) get_option( 'vira_code_log_limit', 100 ); // Default to 100.
}

/**
	* Clear execution logs.
	*
	* @return bool
	*/
function vira_code_clear_logs() {
	return delete_transient( 'vira_code_execution_logs' );
}

/**
 * Check if user can manage snippets.
 *
 * @return bool
 */
function vira_code_user_can_manage() {
	return current_user_can( apply_filters( 'vira_code/manage_capability', 'manage_options' ) );
}

/**
 * Get asset URL with version for cache busting.
 *
 * @param string $asset Asset path relative to resources directory.
 * @return string
 */
function vira_code_asset_url( $asset ) {
	$file_path = vira_code_path( 'resources/' . ltrim( $asset, '/' ) );
	$file_url  = vira_code_url( 'resources/' . ltrim( $asset, '/' ) );

	// Add file modification time for cache busting.
	if ( file_exists( $file_path ) ) {
		return add_query_arg( 'ver', filemtime( $file_path ), $file_url );
	}

	return add_query_arg( 'ver', vira_code_version(), $file_url );
}

/**
 * Render a view file.
 *
 * @param string $view View file name (without .php extension).
 * @param array  $data Data to pass to the view.
 * @return void
 */
function vira_code_view( $view, $data = array() ) {
	$view_file = vira_code_path( 'app/Views/' . $view . '.php' );

	if ( ! file_exists( $view_file ) ) {
		return;
	}

	// Extract data to variables.
	if ( ! empty( $data ) ) {
		extract( $data, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
	}

	include $view_file;
}

/**
 * Get nonce action for AJAX requests.
 *
 * @return string
 */
function vira_code_nonce_action() {
	return 'vira_code_nonce_action';
}

/**
 * Get nonce field name.
 *
 * @return string
 */
function vira_code_nonce_field() {
	return 'vira_code_nonce';
}

/**
 * Verify nonce for AJAX requests.
 *
 * @param string $nonce Nonce to verify.
 * @return bool
 */
function vira_code_verify_nonce( $nonce ) {
	return wp_verify_nonce( $nonce, vira_code_nonce_action() );
}
