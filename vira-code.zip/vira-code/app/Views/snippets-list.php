<?php
/**
 * Snippets List View
 *
 * @package ViraCode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap vira-code-admin">
	<h1 class="wp-heading-inline">
		<?php esc_html_e( 'Code Snippets', 'vira-code' ); ?>
	</h1>
	<a href="<?php echo esc_url( admin_url( 'admin.php?page=vira-code-new' ) ); ?>" class="page-title-action">
		<?php esc_html_e( 'Add New', 'vira-code' ); ?>
	</a>
	<hr class="wp-header-end">

	<?php if ( \ViraCode\vira_code_is_safe_mode() ) : ?>
		<div class="notice notice-warning">
			<p>
				<strong><?php esc_html_e( 'Safe Mode is Active', 'vira-code' ); ?></strong> -
				<?php esc_html_e( 'All snippets are currently disabled.', 'vira-code' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=vira-code-settings' ) ); ?>">
					<?php esc_html_e( 'Disable Safe Mode', 'vira-code' ); ?>
				</a>
			</p>
		</div>
	<?php endif; ?>

	<!-- Statistics Cards -->
	<div class="vira-stats-cards">
		<div class="vira-stat-card">
			<div class="vira-stat-value"><?php echo esc_html( $stats['total'] ); ?></div>
			<div class="vira-stat-label"><?php esc_html_e( 'Total Snippets', 'vira-code' ); ?></div>
		</div>
		<div class="vira-stat-card vira-stat-active">
			<div class="vira-stat-value"><?php echo esc_html( $stats['active'] ); ?></div>
			<div class="vira-stat-label"><?php esc_html_e( 'Active', 'vira-code' ); ?></div>
		</div>
		<div class="vira-stat-card vira-stat-inactive">
			<div class="vira-stat-value"><?php echo esc_html( $stats['inactive'] ); ?></div>
			<div class="vira-stat-label"><?php esc_html_e( 'Inactive', 'vira-code' ); ?></div>
		</div>
		<div class="vira-stat-card vira-stat-error">
			<div class="vira-stat-value"><?php echo esc_html( $stats['error'] ); ?></div>
			<div class="vira-stat-label"><?php esc_html_e( 'Errors', 'vira-code' ); ?></div>
		</div>
	</div>

	<?php if ( empty( $snippets ) ) : ?>
		<div class="vira-empty-state">
			<div class="vira-empty-icon">
				<span class="dashicons dashicons-editor-code"></span>
			</div>
			<h2><?php esc_html_e( 'No Snippets Found', 'vira-code' ); ?></h2>
			<p><?php esc_html_e( 'Get started by creating your first code snippet.', 'vira-code' ); ?></p>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=vira-code-new' ) ); ?>" class="button button-primary button-hero">
				<?php esc_html_e( 'Add Your First Snippet', 'vira-code' ); ?>
			</a>
		</div>
	<?php else : ?>
		<table class="wp-list-table widefat fixed striped vira-snippets-table">
			<thead>
				<tr>
					<th class="column-title column-primary"><?php esc_html_e( 'Title', 'vira-code' ); ?></th>
					<th class="column-type"><?php esc_html_e( 'Type', 'vira-code' ); ?></th>
					<th class="column-scope"><?php esc_html_e( 'Scope', 'vira-code' ); ?></th>
					<th class="column-status"><?php esc_html_e( 'Status', 'vira-code' ); ?></th>
					<th class="column-priority"><?php esc_html_e( 'Priority', 'vira-code' ); ?></th>
					<th class="column-updated"><?php esc_html_e( 'Last Updated', 'vira-code' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $snippets as $snippet ) : ?>
					<tr data-snippet-id="<?php echo esc_attr( $snippet['id'] ); ?>">
						<td class="column-title column-primary" data-colname="<?php esc_attr_e( 'Title', 'vira-code' ); ?>">
							<strong>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=vira-code-new&id=' . $snippet['id'] ) ); ?>" class="row-title">
									<?php echo esc_html( $snippet['title'] ); ?>
								</a>
							</strong>
							<?php if ( ! empty( $snippet['description'] ) ) : ?>
								<p class="snippet-description"><?php echo esc_html( wp_trim_words( $snippet['description'], 15 ) ); ?></p>
							<?php endif; ?>
							<div class="row-actions">
								<span class="edit">
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=vira-code-new&id=' . $snippet['id'] ) ); ?>">
										<?php esc_html_e( 'Edit', 'vira-code' ); ?>
									</a> |
								</span>
								<span class="toggle">
									<a href="javascript:void(0);" class="vira-toggle-snippet" data-id="<?php echo esc_attr( $snippet['id'] ); ?>">
										<?php echo 'active' === $snippet['status'] ? esc_html__( 'Deactivate', 'vira-code' ) : esc_html__( 'Activate', 'vira-code' ); ?>
									</a> |
								</span>
								<span class="trash">
									<a href="javascript:void(0);" class="vira-delete-snippet" data-id="<?php echo esc_attr( $snippet['id'] ); ?>">
										<?php esc_html_e( 'Delete', 'vira-code' ); ?>
									</a>
								</span>
							</div>
						</td>
						<td class="column-type" data-colname="<?php esc_attr_e( 'Type', 'vira-code' ); ?>">
							<span class="vira-badge vira-badge-<?php echo esc_attr( $snippet['type'] ); ?>">
								<?php echo esc_html( strtoupper( $snippet['type'] ) ); ?>
							</span>
						</td>
						<td class="column-scope" data-colname="<?php esc_attr_e( 'Scope', 'vira-code' ); ?>">
							<?php
							$scopes = \ViraCode\vira_code_snippet_scopes();
							echo esc_html( $scopes[ $snippet['scope'] ] ?? $snippet['scope'] );
							?>
						</td>
						<td class="column-status" data-colname="<?php esc_attr_e( 'Status', 'vira-code' ); ?>">
							<?php
							$status_class = 'active' === $snippet['status'] ? 'success' : ( 'error' === $snippet['status'] ? 'error' : 'default' );
							$status_text  = ucfirst( $snippet['status'] );
							?>
							<span class="vira-status vira-status-<?php echo esc_attr( $status_class ); ?>">
								<?php echo esc_html( $status_text ); ?>
							</span>
							<?php if ( 'error' === $snippet['status'] && ! empty( $snippet['error_message'] ) ) : ?>
								<span class="dashicons dashicons-warning" title="<?php echo esc_attr( $snippet['error_message'] ); ?>"></span>
							<?php endif; ?>
						</td>
						<td class="column-priority" data-colname="<?php esc_attr_e( 'Priority', 'vira-code' ); ?>">
							<?php echo esc_html( $snippet['priority'] ); ?>
						</td>
						<td class="column-updated" data-colname="<?php esc_attr_e( 'Last Updated', 'vira-code' ); ?>">
							<?php
							$updated_time = strtotime( $snippet['updated_at'] );
							echo esc_html( human_time_diff( $updated_time, current_time( 'timestamp' ) ) . ' ' . __( 'ago', 'vira-code' ) );
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr>
					<th class="column-title column-primary"><?php esc_html_e( 'Title', 'vira-code' ); ?></th>
					<th class="column-type"><?php esc_html_e( 'Type', 'vira-code' ); ?></th>
					<th class="column-scope"><?php esc_html_e( 'Scope', 'vira-code' ); ?></th>
					<th class="column-status"><?php esc_html_e( 'Status', 'vira-code' ); ?></th>
					<th class="column-priority"><?php esc_html_e( 'Priority', 'vira-code' ); ?></th>
					<th class="column-updated"><?php esc_html_e( 'Last Updated', 'vira-code' ); ?></th>
				</tr>
			</tfoot>
		</table>
	<?php endif; ?>
</div>

<script type="text/javascript">
// Ensure viraCode object is available before initializing
(function($) {
	// Create viraCode object immediately if it doesn't exist
	if (typeof window.viraCode === 'undefined') {
		window.viraCode = {
			ajaxUrl: '<?php echo admin_url("admin-ajax.php"); ?>',
			nonce: '<?php echo wp_create_nonce(\ViraCode\vira_code_nonce_action()); ?>',
			i18n: {
				confirm_delete: '<?php echo esc_js(__("Are you sure you want to delete this snippet?", "vira-code")); ?>',
				delete_error: '<?php echo esc_js(__("Error deleting snippet. Please try again.", "vira-code")); ?>'
			}
		};
		console.log('[Vira Code] Created viraCode object inline');
	}
	
	// Function to initialize the event handlers
	function initSnippetsList() {
		// Debug logging
		if (window.console && console.log) {
			console.log('[Vira Code] Initializing snippets list');
			console.log('[Vira Code] viraCode object available:', typeof viraCode !== 'undefined');
			if (typeof viraCode !== 'undefined') {
				console.log('[Vira Code] AJAX URL:', viraCode.ajaxUrl);
				console.log('[Vira Code] Nonce present:', !!viraCode.nonce);
			}
		}
		
		// Bind click events for toggle links
		$(document).on('click', '.vira-toggle-snippet', function(e) {
			e.preventDefault();
			e.stopPropagation();
			
			const link = $(this);
			const snippetId = link.data('id');
			const row = link.closest('tr');
			
			console.log('[Vira Code] Toggle clicked for snippet ID:', snippetId);
			
			// Send AJAX request
			$.ajax({
				url: viraCode.ajaxUrl,
				type: 'POST',
				data: {
					action: 'vira_code_toggle_snippet',
					nonce: viraCode.nonce,
					id: snippetId,
				},
				beforeSend: function() {
					row.addClass('vira-loading');
				},
				success: function(response) {
					console.log('[Vira Code] Toggle response:', response);
					
					if (response.success) {
						// Update link text
						const newText = response.data.status === 'active' ? 'Deactivate' : 'Activate';
						link.text(newText);
						
						// Update status badge
						const statusCell = row.find('.column-status');
						const statusClass = response.data.status === 'active' ? 'success' : 'default';
						const statusText = response.data.status.charAt(0).toUpperCase() + response.data.status.slice(1);
						statusCell.html('<span class="vira-status vira-status-' + statusClass + '">' + statusText + '</span>');
						
						// Update statistics
						updateStatistics();
						
						// Show success message
						showNotice('success', response.data.message);
					} else {
						showNotice('error', response.data.message || 'Failed to toggle snippet status.');
					}
					
					row.removeClass('vira-loading');
				},
				error: function(xhr, status, error) {
					console.error('[Vira Code] AJAX error:', { status: status, error: error, xhr: xhr });
					row.removeClass('vira-loading');
					showNotice('error', 'An error occurred. Please try again.');
				}
			});
		});
		
		// Bind click events for delete links
		$(document).on('click', '.vira-delete-snippet', function(e) {
			e.preventDefault();
			e.stopPropagation();
			
			if (!confirm(viraCode.i18n.confirm_delete || 'Are you sure you want to delete this snippet?')) {
				return;
			}
			
			const link = $(this);
			const snippetId = link.data('id');
			const row = link.closest('tr');
			
			console.log('[Vira Code] Delete clicked for snippet ID:', snippetId);
			
			// Send AJAX request
			$.ajax({
				url: viraCode.ajaxUrl,
				type: 'POST',
				data: {
					action: 'vira_code_delete_snippet',
					nonce: viraCode.nonce,
					id: snippetId,
				},
				beforeSend: function() {
					row.addClass('vira-loading');
				},
				success: function(response) {
					if (response.success) {
						row.fadeOut(300, function() {
							$(this).remove();
							updateStatistics();
							showNotice('success', response.data.message);
						});
					} else {
						row.removeClass('vira-loading');
						showNotice('error', response.data.message || viraCode.i18n.delete_error);
					}
				},
				error: function(xhr, status, error) {
					console.error('[Vira Code] AJAX error:', { status: status, error: error, xhr: xhr });
					row.removeClass('vira-loading');
					showNotice('error', 'An error occurred. Please try again.');
				}
			});
		});
	}
	
	// Function to update statistics
	function updateStatistics() {
		$.ajax({
			url: viraCode.ajaxUrl,
			type: 'POST',
			data: {
				action: 'vira_code_get_statistics',
				nonce: viraCode.nonce,
			},
			success: function(statsResponse) {
				if (statsResponse.success && statsResponse.data.stats) {
					$('.vira-stat-value').each(function(index) {
						const statKey = ['total', 'active', 'inactive', 'error'][index];
						if (statsResponse.data.stats[statKey] !== undefined) {
							$(this).text(statsResponse.data.stats[statKey]);
						}
					});
				}
			}
		});
	}
	
	// Function to show notices
	function showNotice(type, message) {
		if (window.ViraCodeAdmin && typeof ViraCodeAdmin.showNotice === 'function') {
			ViraCodeAdmin.showNotice(type, message);
		} else {
			alert(type.charAt(0).toUpperCase() + type.slice(1) + ': ' + message);
		}
	}
	
	// Initialize immediately
	initSnippetsList();
	
})(jQuery);
</script>
